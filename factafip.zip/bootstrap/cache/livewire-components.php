<?php return array (
  'assets.bookmark' => 'App\\Http\\Livewire\\Assets\\Bookmark',
  'customers.show' => 'App\\Http\\Livewire\\Customers\\Show',
  'invoice.create' => 'App\\Http\\Livewire\\Invoice\\Create',
  'products.show' => 'App\\Http\\Livewire\\Products\\Show',
  'warehouse-table' => 'App\\Http\\Livewire\\WarehouseTable',
  'warehouses.show' => 'App\\Http\\Livewire\\Warehouses\\Show',
);